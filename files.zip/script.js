/* ============================================================
   CAMPUSAI — App logic
   Pure client-side. The "AI assistant" and "notice summarizer"
   below are rule-based so the prototype runs with zero API
   keys. See README.md for how to swap in a real Claude API
   call for production.
   ============================================================ */

(function () {
  "use strict";

  /* ---------- Navigation ---------- */
  const sections = document.querySelectorAll("[data-section]");
  const navLinks = document.querySelectorAll("[data-nav]");

  function showSection(id) {
    sections.forEach((s) => s.classList.toggle("is-active", s.dataset.section === id));
    navLinks.forEach((l) => l.classList.toggle("is-active", l.dataset.nav === id));
    window.scrollTo({ top: 0, behavior: "smooth" });
    document.body.classList.remove("nav-open");
  }

  navLinks.forEach((link) => {
    link.addEventListener("click", (e) => {
      e.preventDefault();
      showSection(link.dataset.nav);
    });
  });

  document.querySelectorAll("[data-go]").forEach((btn) => {
    btn.addEventListener("click", () => showSection(btn.dataset.go));
  });

  const menuToggle = document.querySelector(".menu-toggle");
  if (menuToggle) {
    menuToggle.addEventListener("click", () => document.body.classList.toggle("nav-open"));
  }

  /* ---------- Helpers ---------- */
  function norm(str) {
    return (str || "").toLowerCase().trim();
  }

  function scoreMatch(query, hay) {
    query = norm(query);
    hay = norm(hay);
    if (!query || !hay) return 0;
    if (hay === query) return 100;
    if (hay.includes(query) || query.includes(hay)) return 60;
    const qWords = query.split(/\s+/).filter((w) => w.length > 2);
    let hits = 0;
    qWords.forEach((w) => { if (hay.includes(w)) hits++; });
    return hits * 10;
  }

  function findLocation(query) {
    let best = null, bestScore = 0;
    LOCATIONS.forEach((loc) => {
      let score = scoreMatch(query, loc.name);
      score = Math.max(score, scoreMatch(query, loc.block));
      loc.tags.forEach((t) => { score = Math.max(score, scoreMatch(query, t)); });
      if (score > bestScore) { bestScore = score; best = loc; }
    });
    // department synonym pass
    Object.keys(DEPARTMENTS).forEach((key) => {
      if (norm(query).includes(key)) {
        const loc = LOCATIONS.find((l) => l.id === DEPARTMENTS[key]);
        if (loc) { best = loc; bestScore = Math.max(bestScore, 80); }
      }
    });
    return bestScore >= 15 ? best : null;
  }

  function findFaculty(query) {
    const q = norm(query);
    let best = null, bestScore = 0;
    FACULTY.forEach((f) => {
      let score = scoreMatch(query, f.name);
      f.subjects.forEach((s) => { score = Math.max(score, scoreMatch(query, s)); });
      score = Math.max(score, scoreMatch(query, f.dept));
      if (score > bestScore) { bestScore = score; best = f; }
    });
    return bestScore >= 15 ? best : null;
  }

  function findFaq(query) {
    const q = norm(query);
    for (const item of FAQ) {
      if (item.q.some((k) => q.includes(k))) return item.a;
    }
    return null;
  }

  /* ---------- AI Assistant ---------- */
  const chatLog = document.getElementById("chat-log");
  const chatForm = document.getElementById("chat-form");
  const chatInput = document.getElementById("chat-input");

  function addBubble(text, who) {
    const bubble = document.createElement("div");
    bubble.className = "bubble bubble--" + who;
    bubble.innerHTML = text;
    chatLog.appendChild(bubble);
    chatLog.scrollTop = chatLog.scrollHeight;
    return bubble;
  }

  function locationAnswerHTML(loc) {
    return `
      <div class="answer-card">
        <div class="answer-card__title">📍 ${loc.name}</div>
        <dl class="answer-card__meta">
          <div><dt>Block</dt><dd>${loc.block}</dd></div>
          <div><dt>Floor</dt><dd>${loc.floor}</dd></div>
          <div><dt>Room</dt><dd>${loc.room}</dd></div>
        </dl>
        <p class="answer-card__desc">${loc.desc}</p>
        <p class="answer-card__walk">🚶 ${loc.walk}</p>
        <button class="btn btn--small" data-open-map="${loc.id}">View on map</button>
      </div>`;
  }

  function facultyAnswerHTML(f) {
    return `
      <div class="answer-card">
        <div class="answer-card__title">👨‍🏫 ${f.name}</div>
        <dl class="answer-card__meta">
          <div><dt>Subjects</dt><dd>${f.subjects.join(", ")}</dd></div>
          <div><dt>Department</dt><dd>${f.dept}</dd></div>
          <div><dt>Office</dt><dd>${f.block} — Room ${f.room}</dd></div>
        </dl>
      </div>`;
  }

  function answerQuery(query) {
    const q = norm(query);

    const teachMatch = q.match(/who teaches ([a-z0-9 &+#/-]+)/) || q.match(/([a-z0-9 &+#/-]+) faculty/);
    if (teachMatch) {
      const f = findFaculty(teachMatch[1]);
      if (f) return facultyAnswerHTML(f);
    }

    const faq = findFaq(q);
    if (faq) return `<div class="answer-card"><p class="answer-card__desc">${faq}</p></div>`;

    const loc = findLocation(q);
    if (loc) return locationAnswerHTML(loc);

    const fac = findFaculty(q);
    if (fac) return facultyAnswerHTML(fac);

    return `<div class="answer-card">
      <p class="answer-card__desc">I couldn't find that in the campus database yet. Try asking about a building, lab, department, or faculty member — or browse the <button class="link-btn" data-go="map">Campus Map</button> and <button class="link-btn" data-go="faculty">Faculty Finder</button> directly.</p>
    </div>`;
  }

  if (chatForm) {
    chatForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const value = chatInput.value.trim();
      if (!value) return;
      addBubble(escapeHtml(value), "user");
      chatInput.value = "";
      const thinking = addBubble('<span class="typing"><span></span><span></span><span></span></span>', "ai");
      setTimeout(() => {
        thinking.innerHTML = answerQuery(value);
        wireInlineButtons(thinking);
      }, 380);
    });
  }

  function escapeHtml(s) {
    const div = document.createElement("div");
    div.textContent = s;
    return div.innerHTML;
  }

  function wireInlineButtons(scope) {
    scope.querySelectorAll("[data-open-map]").forEach((btn) => {
      btn.addEventListener("click", () => {
        showSection("map");
        openLocationPanel(btn.dataset.openMap);
      });
    });
    scope.querySelectorAll("[data-go]").forEach((btn) => {
      btn.addEventListener("click", () => showSection(btn.dataset.go));
    });
  }

  // Hero quick-search feeds the assistant
  const heroForm = document.getElementById("hero-search-form");
  const heroInput = document.getElementById("hero-search-input");
  if (heroForm) {
    heroForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const value = heroInput.value.trim();
      if (!value) return;
      showSection("assistant");
      chatInput.value = value;
      chatForm.dispatchEvent(new Event("submit"));
    });
  }

  document.querySelectorAll("[data-ask]").forEach((chip) => {
    chip.addEventListener("click", () => {
      showSection("assistant");
      chatInput.value = chip.dataset.ask;
      chatForm.dispatchEvent(new Event("submit"));
    });
  });

  /* ---------- Campus Map ---------- */
  const mapSvg = document.getElementById("campus-map");
  const mapPanel = document.getElementById("map-panel");

  function renderMap() {
    if (!mapSvg) return;
    const paths = `
      <line x1="360" y1="60" x2="360" y2="140" class="map-path" />
      <line x1="360" y1="180" x2="360" y2="230" class="map-path" />
      <line x1="360" y1="230" x2="220" y2="260" class="map-path" />
      <line x1="360" y1="230" x2="520" y2="260" class="map-path" />
      <line x1="220" y1="300" x2="220" y2="420" class="map-path" />
      <line x1="220" y1="420" x2="280" y2="420" class="map-path" />
    `;
    const blocks = LOCATIONS.filter((l) => l.id !== "main-gate");
    const nodes = LOCATIONS.map((loc) => {
      const isGate = loc.id === "main-gate";
      const w = isGate ? 90 : 110, h = isGate ? 34 : 44;
      return `
        <g class="map-node" tabindex="0" role="button" aria-label="${loc.name}" data-loc="${loc.id}" transform="translate(${loc.x - w / 2}, ${loc.y - h / 2})">
          <rect width="${w}" height="${h}" rx="6" class="map-node__box ${isGate ? "map-node__box--gate" : ""}"></rect>
          <text x="${w / 2}" y="${h / 2 + 4}" text-anchor="middle" class="map-node__label">${loc.name}</text>
        </g>`;
    }).join("");
    mapSvg.innerHTML = `<g class="map-paths">${paths}</g>${nodes}`;

    mapSvg.querySelectorAll(".map-node").forEach((node) => {
      node.addEventListener("click", () => openLocationPanel(node.dataset.loc));
      node.addEventListener("keypress", (e) => {
        if (e.key === "Enter") openLocationPanel(node.dataset.loc);
      });
    });
  }

  function openLocationPanel(id) {
    const loc = LOCATIONS.find((l) => l.id === id);
    if (!loc || !mapPanel) return;
    mapSvg.querySelectorAll(".map-node__box").forEach((b) => b.classList.remove("is-selected"));
    const activeNode = mapSvg.querySelector(`.map-node[data-loc="${id}"] .map-node__box`);
    if (activeNode) activeNode.classList.add("is-selected");

    mapPanel.classList.add("is-open");
    mapPanel.innerHTML = `
      <div class="map-panel__title">${loc.name}</div>
      <dl class="answer-card__meta">
        <div><dt>Block</dt><dd>${loc.block}</dd></div>
        <div><dt>Floor</dt><dd>${loc.floor}</dd></div>
        <div><dt>Room</dt><dd>${loc.room}</dd></div>
      </dl>
      <p class="answer-card__desc">${loc.desc}</p>
      <p class="answer-card__walk">🚶 ${loc.walk}</p>
    `;
  }

  renderMap();

  /* ---------- Faculty Finder ---------- */
  const facultyGrid = document.getElementById("faculty-grid");
  const facultySearch = document.getElementById("faculty-search");

  function renderFaculty(list) {
    if (!facultyGrid) return;
    if (!list.length) {
      facultyGrid.innerHTML = `<p class="empty-state">No faculty matched that search. Try a subject name like "Python" or a department like "ECE".</p>`;
      return;
    }
    facultyGrid.innerHTML = list.map((f) => `
      <article class="faculty-card">
        <h3>${f.name}</h3>
        <p class="faculty-card__subject">${f.subjects.join(" · ")}</p>
        <dl class="answer-card__meta">
          <div><dt>Department</dt><dd>${f.dept}</dd></div>
          <div><dt>Office</dt><dd>${f.block} — ${f.room}</dd></div>
        </dl>
        <a class="faculty-card__email" href="mailto:${f.email}">${f.email}</a>
      </article>
    `).join("");
  }

  if (facultySearch) {
    renderFaculty(FACULTY);
    facultySearch.addEventListener("input", () => {
      const q = norm(facultySearch.value);
      if (!q) { renderFaculty(FACULTY); return; }
      const filtered = FACULTY.filter((f) =>
        norm(f.name).includes(q) ||
        norm(f.dept).includes(q) ||
        f.subjects.some((s) => norm(s).includes(q))
      );
      renderFaculty(filtered);
    });
  }

  /* ---------- Events ---------- */
  const eventsList = document.getElementById("events-list");
  if (eventsList) {
    const sorted = [...EVENTS].sort((a, b) => new Date(a.date) - new Date(b.date));
    eventsList.innerHTML = sorted.map((ev) => {
      const d = new Date(ev.date);
      const day = d.toLocaleDateString(undefined, { day: "2-digit" });
      const month = d.toLocaleDateString(undefined, { month: "short" });
      return `
        <article class="event-card">
          <div class="event-card__date"><span>${day}</span>${month}</div>
          <div class="event-card__body">
            <p class="event-card__tag">${ev.tag}</p>
            <h3>${ev.title}</h3>
            <p class="event-card__meta">${ev.time} · ${ev.location}</p>
          </div>
        </article>`;
    }).join("");
  }

  /* ---------- I'm Lost ---------- */
  const lostFrom = document.getElementById("lost-from");
  const lostTo = document.getElementById("lost-to");
  const lostForm = document.getElementById("lost-form");
  const lostResult = document.getElementById("lost-result");

  function fillSelect(select) {
    if (!select) return;
    select.innerHTML = LOCATIONS.map((l) => `<option value="${l.id}">${l.name}</option>`).join("");
  }
  fillSelect(lostFrom);
  fillSelect(lostTo);
  if (lostTo) lostTo.value = "aiml-lab";

  if (lostForm) {
    lostForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const from = lostFrom.value, to = lostTo.value;
      const fromLoc = LOCATIONS.find((l) => l.id === from);
      const toLoc = LOCATIONS.find((l) => l.id === to);
      const key = `${from}|${to}`;
      const steps = ROUTES[key];

      if (from === to) {
        lostResult.innerHTML = `<p class="empty-state">You're already there — enjoy ${toLoc.name}!</p>`;
      } else if (steps) {
        lostResult.innerHTML = `
          <div class="route">
            <div class="route__ends"><strong>${fromLoc.name}</strong> → <strong>${toLoc.name}</strong></div>
            <ol class="route__steps">
              ${steps.map((s) => `<li>${s}</li>`).join("")}
            </ol>
            <p class="route__arrival">🎯 You've arrived at ${toLoc.name}.</p>
          </div>`;
      } else {
        lostResult.innerHTML = `
          <div class="route">
            <div class="route__ends"><strong>${fromLoc.name}</strong> → <strong>${toLoc.name}</strong></div>
            <ol class="route__steps">
              <li>Head from ${fromLoc.name} toward the central pathway</li>
              <li>Follow signs toward ${toLoc.block}</li>
              <li>Ask campus security near Admin Block if unsure — this exact route isn't mapped yet in the prototype</li>
            </ol>
          </div>`;
      }
    });
  }

  /* ---------- Notice Summarizer (rule-based extraction) ---------- */
  const noticeInput = document.getElementById("notice-input");
  const noticeForm = document.getElementById("notice-form");
  const noticeResult = document.getElementById("notice-result");
  const noticeFile = document.getElementById("notice-file");
  const sampleNoticeBtn = document.getElementById("notice-sample");

  const SAMPLE_NOTICE = `NOTICE — MID-SEMESTER EXAMINATION

All students are hereby informed that the Mid-Semester Examination for the current academic term will be conducted as per the schedule below.

Date: 15 September 2026
Time: 10:00 AM onwards
Venue: Academic Block, respective classrooms

Students must carry their College ID card and admit card to the examination hall. Entry will not be permitted without valid identification.

Please note that registration for the examination closes on 10 September 2026. Students who fail to register before the deadline will not be permitted to appear.

By order of the Examination Committee.`;

  if (sampleNoticeBtn) {
    sampleNoticeBtn.addEventListener("click", () => {
      noticeInput.value = SAMPLE_NOTICE;
    });
  }

  if (noticeFile) {
    noticeFile.addEventListener("change", () => {
      const file = noticeFile.files[0];
      if (!file) return;
      if (file.type && !file.type.startsWith("text") && !file.name.endsWith(".txt")) {
        noticeResult.innerHTML = `<p class="empty-state">This demo reads plain-text notices (.txt) directly in the browser. PDFs/images would be sent to a document-parsing + LLM API in production — see README.md.</p>`;
        return;
      }
      const reader = new FileReader();
      reader.onload = () => { noticeInput.value = reader.result; };
      reader.readAsText(file);
    });
  }

  function extractNotice(text) {
    const lines = text.split(/\n+/).map((l) => l.trim()).filter(Boolean);

    // WHAT: first heading-like line, else first sentence
    let what = lines.find((l) => /notice|exam|meeting|fest|drive|holiday|circular|reminder/i.test(l)) || lines[0] || "—";
    what = what.replace(/^notice\s*[—-]?\s*/i, "").trim();

    // DATE
    const dateRegex = /\b(\d{1,2}\s+(?:january|february|march|april|may|june|july|august|september|october|november|december)\s+\d{4}|\d{1,2}\/\d{1,2}\/\d{2,4}|\d{4}-\d{2}-\d{2})\b/i;
    const dateMatch = text.match(dateRegex);

    // TIME
    const timeRegex = /\b(\d{1,2}(:\d{2})?\s?(am|pm|AM|PM))\b/;
    const timeMatch = text.match(timeRegex);

    // LOCATION / VENUE
    const venueRegex = /(?:venue|location|held at|at the)\s*[:\-]?\s*([^\n.]+)/i;
    const venueMatch = text.match(venueRegex);

    // BRING
    const bringRegex = /(?:carry|bring)\s+([^\n.]+)/i;
    const bringMatch = text.match(bringRegex);

    // DEADLINE
    const deadlineRegex = /(?:deadline|closes|last date|before)\s*[:\-]?\s*([^\n.]+)/i;
    const deadlineMatch = text.match(deadlineRegex);

    return {
      what: what.slice(0, 120),
      date: dateMatch ? dateMatch[0] : null,
      time: timeMatch ? timeMatch[0] : null,
      location: venueMatch ? venueMatch[1].trim().slice(0, 80) : null,
      bring: bringMatch ? bringMatch[1].trim().slice(0, 80) : null,
      deadline: deadlineMatch ? deadlineMatch[0].trim().slice(0, 100) : null,
    };
  }

  if (noticeForm) {
    noticeForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const text = noticeInput.value.trim();
      if (!text) return;
      const info = extractNotice(text);
      noticeResult.innerHTML = `
        <div class="notice-card">
          <p class="notice-card__eyebrow">Important notice</p>
          <div class="notice-card__row"><span>What</span><strong>${info.what}</strong></div>
          ${info.date ? `<div class="notice-card__row"><span>📅 Date</span><strong>${info.date}</strong></div>` : ""}
          ${info.time ? `<div class="notice-card__row"><span>⏰ Time</span><strong>${info.time}</strong></div>` : ""}
          ${info.location ? `<div class="notice-card__row"><span>📍 Location</span><strong>${info.location}</strong></div>` : ""}
          ${info.bring ? `<div class="notice-card__row"><span>🎒 Bring</span><strong>${info.bring}</strong></div>` : ""}
          ${info.deadline ? `<div class="notice-card__row notice-card__row--warn"><span>⚠️ Deadline</span><strong>${info.deadline}</strong></div>` : ""}
        </div>`;
    });
  }

})();
