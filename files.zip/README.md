# CampusAI

AI-powered campus navigation & student assistant — hackathon prototype.

## Run it

No build step. Just open `index.html` in a browser, or serve the folder:

```
cd campusai
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.

## What's built

| Feature | Status | File |
|---|---|---|
| 🤖 AI Assistant | Working (rule-based) | `script.js` → `answerQuery()` |
| 🗺️ Campus Map | Working (custom SVG, clickable) | `script.js` → `renderMap()` |
| 📢 Notice Summarizer | Working (regex extraction) | `script.js` → `extractNotice()` |
| 👨‍🏫 Faculty Finder | Working (search/filter) | `script.js` |
| 📅 Events | Working (static list) | `script.js` |
| 🆘 I'm Lost | Working (predefined routes) | `script.js` → `ROUTES` in `data.js` |

All content — locations, faculty, notices, events, routes — lives in **`data.js`**. Edit that one file to point the whole site at your real campus.

## Why rule-based, not a live LLM call

This environment can't ship an API key, so the "AI" here is deterministic keyword/tag matching against `data.js` — it works fully offline and is honest about being a prototype. For your actual hackathon submission you have two good options:

**Option A — keep it simple (recommended for a 1-week build).**
Keep the rule-based matching. It's fast, needs no backend, never "hallucinates" a wrong room number, and is easy to demo reliably. Judges care that it works live more than that it's a "real" LLM.

**Option B — wire in a real LLM for more natural answers.**
Call the Claude API from a tiny backend (never expose an API key in frontend JS) and pass it your campus data as context, e.g.:

```js
// server-side (Node/Express, Cloudflare Worker, etc.)
const response = await fetch("https://api.anthropic.com/v1/messages", {
  method: "POST",
  headers: {
    "x-api-key": process.env.ANTHROPIC_API_KEY,
    "anthropic-version": "2023-06-01",
    "content-type": "application/json",
  },
  body: JSON.stringify({
    model: "claude-sonnet-4-6",
    max_tokens: 400,
    system: `You are CampusAI. Answer ONLY using this campus data: ${JSON.stringify(LOCATIONS)}. If the answer isn't in the data, say so.`,
    messages: [{ role: "user", content: userQuestion }],
  }),
});
```

Same idea for the notice summarizer — send the pasted notice text to the LLM with a prompt asking for structured fields (date, time, venue, deadline, what to bring) instead of the regex heuristics in `extractNotice()`.

## Extending with a real database

Replace `data.js` with calls to Firebase or Supabase:

- `locations` collection → powers Assistant + Map + I'm Lost
- `faculty` collection → powers Faculty Finder
- `notices` collection → could store past summarized notices
- `events` collection → powers Events

Keep the shape of each object the same as in `data.js` and the rest of the app keeps working unchanged.

## Team split (4 people)

- **Frontend** — `index.html` / `styles.css`, homepage, nav, mobile layout
- **AI** — `answerQuery()`, `extractNotice()` in `script.js` (or the real LLM integration above)
- **Database + Map** — `data.js` content, `renderMap()`, `ROUTES`
- **Integration + pitch** — wiring it all together, testing, the demo script

## Demo script (2 minutes)

1. Type "Where is the AI & ML Lab?" in the Assistant → instant answer with room + walk time.
2. Click **View on map** → building highlights on the Campus Map.
3. Go to Notices → click **Try a sample notice** → **Summarize notice** → structured card appears.
4. Go to I'm Lost → Main Gate → AI & ML Lab → **Get directions** → step-by-step route.

## Scope notes

Deliberately **not** built (per hackathon scope guidance): real-time GPS, face recognition, voice assistant, a full ERP, or a custom-trained model. Faculty/notice/event data is sample data — swap in your real college's data before presenting.
