/* ============================================================
   CAMPUSAI — Campus Data
   Replace this file with a real feed (Firebase/Supabase/API)
   for production. Everything below is sample/demo data.
   ============================================================ */

const CAMPUS = {
  name: "Greenfield Institute of Technology",
  gateName: "Main Gate",
  libraryHours: "8:30 AM – 7:00 PM, Monday to Saturday",
  canteenHours: "8:00 AM – 6:30 PM, Monday to Saturday",
};

const LOCATIONS = [
  { id: "main-gate", name: "Main Gate", block: "—", floor: "Ground",
    room: "—", tags: ["entrance", "gate", "parking"],
    desc: "The main entrance to campus, facing College Road.",
    walk: "Start here", x: 360, y: 40 },

  { id: "admin", name: "Admin Block", block: "Admin Block", floor: "Ground",
    room: "AD-01 to AD-12", tags: ["admin", "office", "principal", "accounts", "fees"],
    desc: "Principal's office, accounts, admissions and general administration.",
    walk: "1 min from Main Gate", x: 360, y: 140 },

  { id: "academic", name: "Academic Block", block: "Academic Block", floor: "Multiple",
    room: "A101–A320", tags: ["classrooms", "labs", "cse", "aiml", "ece"],
    desc: "Classrooms and labs for CSE, AI & ML and ECE departments.",
    walk: "3 min from Main Gate", x: 200, y: 260 },

  { id: "aiml-lab", name: "AI & ML Laboratory", block: "Academic Block", floor: "2nd Floor",
    room: "A204", tags: ["ai", "ml", "lab", "artificial intelligence", "machine learning"],
    desc: "The AI & ML department's main systems lab, used for practicals and project work.",
    walk: "Approx. 3 minutes from Main Gate", x: 160, y: 300 },

  { id: "cse-dept", name: "CSE Department", block: "Academic Block", floor: "1st Floor",
    room: "A110", tags: ["cse", "computer science", "hod", "department"],
    desc: "Computer Science & Engineering department office and HOD cabin.",
    walk: "Approx. 3 minutes from Main Gate", x: 220, y: 300 },

  { id: "ece-lab", name: "ECE Lab", block: "Academic Block", floor: "3rd Floor",
    room: "A305", tags: ["ece", "electronics", "communication", "lab"],
    desc: "Electronics & Communication department lab.",
    walk: "4 min from Main Gate", x: 160, y: 340 },

  { id: "library", name: "Central Library", block: "Library Block", floor: "Ground & 1st Floor",
    room: "—", tags: ["library", "books", "reading room", "study"],
    desc: "Reading rooms, book stacks and a digital resource center.",
    walk: "3 min from Main Gate", x: 520, y: 260 },

  { id: "canteen", name: "Canteen", block: "Canteen Block", floor: "Ground",
    room: "—", tags: ["food", "canteen", "mess", "lunch", "snacks"],
    desc: "Main campus canteen serving breakfast, lunch and snacks.",
    walk: "4 min from Main Gate", x: 200, y: 420 },

  { id: "auditorium", name: "Auditorium", block: "Academic Block", floor: "Ground",
    room: "A001", tags: ["auditorium", "events", "seminar", "fest"],
    desc: "Main auditorium used for fests, seminars and guest lectures.",
    walk: "3 min from Main Gate", x: 280, y: 420 },

  { id: "sports", name: "Sports Ground", block: "Outdoor", floor: "—",
    room: "—", tags: ["sports", "ground", "football", "cricket", "athletics"],
    desc: "Open ground used for sports day and evening practice.",
    walk: "6 min from Main Gate", x: 460, y: 420 },

  { id: "hostel-a", name: "Hostel Block A (Boys)", block: "Hostel A", floor: "—",
    room: "—", tags: ["hostel", "boys", "residence"],
    desc: "Boys' hostel, warden's office on the ground floor.",
    walk: "7 min from Main Gate", x: 600, y: 420 },

  { id: "hostel-b", name: "Hostel Block B (Girls)", block: "Hostel B", floor: "—",
    room: "—", tags: ["hostel", "girls", "residence"],
    desc: "Girls' hostel, warden's office on the ground floor.",
    walk: "7 min from Main Gate", x: 660, y: 300 },

  { id: "medical", name: "Medical Room", block: "Admin Block", floor: "Ground",
    room: "AD-03", tags: ["medical", "first aid", "nurse", "emergency"],
    desc: "First-aid and a resident nurse on duty during college hours.",
    walk: "1 min from Main Gate", x: 400, y: 140 },

  { id: "placement", name: "Placement Cell", block: "Admin Block", floor: "1st Floor",
    room: "AD-10", tags: ["placement", "internship", "careers", "tpo"],
    desc: "Training & Placement office for internships and campus drives.",
    walk: "2 min from Main Gate", x: 320, y: 140 },

  { id: "workshop", name: "Mechanical Workshop", block: "Workshop Block", floor: "Ground",
    room: "—", tags: ["mechanical", "workshop", "lathe", "fabrication"],
    desc: "Fabrication and machine workshop for Mechanical Engineering.",
    walk: "6 min from Main Gate", x: 520, y: 420 },

  { id: "parking", name: "Parking Area", block: "Outdoor", floor: "—",
    room: "—", tags: ["parking", "bikes", "cars", "vehicle"],
    desc: "Two-wheeler and four-wheeler parking near the Main Gate.",
    walk: "Right of Main Gate", x: 460, y: 40 },

  { id: "atm", name: "Bank & ATM", block: "Admin Block", floor: "Ground",
    room: "—", tags: ["atm", "bank", "cash", "money"],
    desc: "On-campus ATM kiosk next to the Admin Block entrance.",
    walk: "1 min from Main Gate", x: 260, y: 140 },

  { id: "seminar", name: "Seminar Hall", block: "Library Block", floor: "1st Floor",
    room: "L110", tags: ["seminar", "hall", "workshop", "guest lecture"],
    desc: "Smaller hall for department-level seminars and workshops.",
    walk: "3 min from Main Gate", x: 580, y: 260 },
];

const DEPARTMENTS = {
  "cse": "cse-dept",
  "computer science": "cse-dept",
  "aiml": "aiml-lab",
  "ai": "aiml-lab",
  "ai & ml": "aiml-lab",
  "ai and ml": "aiml-lab",
  "machine learning": "aiml-lab",
  "ece": "ece-lab",
  "electronics": "ece-lab",
};

const FACULTY = [
  { id: "f1", name: "Dr. Ananya Rao", subjects: ["Python Programming", "Data Structures"],
    dept: "CSE", block: "Academic Block", room: "A208", email: "ananya.rao@college.edu" },
  { id: "f2", name: "Prof. Kabir Mehta", subjects: ["Machine Learning", "AI Fundamentals"],
    dept: "AI & ML", block: "Academic Block", room: "A212", email: "kabir.mehta@college.edu" },
  { id: "f3", name: "Dr. Sunita Iyer", subjects: ["Database Management Systems", "SQL"],
    dept: "CSE", block: "Academic Block", room: "A110", email: "sunita.iyer@college.edu" },
  { id: "f4", name: "Prof. Rahul Deshpande", subjects: ["Computer Networks"],
    dept: "CSE", block: "Academic Block", room: "A115", email: "rahul.d@college.edu" },
  { id: "f5", name: "Dr. Meera Nambiar", subjects: ["Web Development", "JavaScript"],
    dept: "CSE", block: "Academic Block", room: "A118", email: "meera.n@college.edu" },
  { id: "f6", name: "Prof. Aditya Verma", subjects: ["Deep Learning", "Neural Networks"],
    dept: "AI & ML", block: "Academic Block", room: "A210", email: "aditya.verma@college.edu" },
  { id: "f7", name: "Dr. Farah Sheikh", subjects: ["Digital Electronics"],
    dept: "ECE", block: "Academic Block", room: "A305", email: "farah.sheikh@college.edu" },
  { id: "f8", name: "Prof. Ojas Kulkarni", subjects: ["Operating Systems", "Python Programming"],
    dept: "CSE", block: "Academic Block", room: "A120", email: "ojas.k@college.edu" },
  { id: "f9", name: "Dr. Priya Nair", subjects: ["Signals & Systems"],
    dept: "ECE", block: "Academic Block", room: "A310", email: "priya.nair@college.edu" },
  { id: "f10", name: "Prof. Vikram Chauhan", subjects: ["Engineering Mechanics"],
    dept: "Mechanical", block: "Workshop Block", room: "W02", email: "vikram.c@college.edu" },
];

const EVENTS = [
  { id: "e1", title: "College Hackathon", date: "2026-09-05", time: "10:00 AM",
    location: "Auditorium", tag: "Tech" },
  { id: "e2", title: "Cultural Fest", date: "2026-09-15", time: "5:00 PM",
    location: "Sports Ground", tag: "Cultural" },
  { id: "e3", title: "Sports Day", date: "2026-09-20", time: "8:00 AM",
    location: "Sports Ground", tag: "Sports" },
  { id: "e4", title: "AI/ML Guest Lecture", date: "2026-09-10", time: "2:00 PM",
    location: "Seminar Hall", tag: "Tech" },
  { id: "e5", title: "Placement Drive — TCS", date: "2026-09-08", time: "9:30 AM",
    location: "Auditorium", tag: "Placement" },
];

/* Predefined step-by-step routes for the "I'm Lost" feature.
   Keyed as "from|to". Add more pairs as needed. */
const ROUTES = {
  "main-gate|aiml-lab": [
    "Enter through Main Gate",
    "Walk straight past the Parking Area",
    "Turn left at Admin Block",
    "Enter Academic Block",
    "Take the stairs to the 2nd floor",
    "AI & ML Lab is Room A204, on your right",
  ],
  "main-gate|library": [
    "Enter through Main Gate",
    "Walk straight past Admin Block",
    "Turn right after the Academic Block",
    "Library Block is directly ahead",
  ],
  "main-gate|canteen": [
    "Enter through Main Gate",
    "Walk straight past Admin Block",
    "Keep the Academic Block on your left",
    "Canteen is at the end of the path",
  ],
  "main-gate|cse-dept": [
    "Enter through Main Gate",
    "Walk straight past the Parking Area",
    "Turn left at Admin Block",
    "Enter Academic Block",
    "CSE Department is on the 1st floor, Room A110",
  ],
  "main-gate|hostel-a": [
    "Enter through Main Gate",
    "Walk straight past Admin Block and the Academic Block",
    "Continue past the Workshop Block",
    "Hostel Block A is on your right",
  ],
  "admin|academic": [
    "Exit Admin Block from the rear door",
    "Cross the central pathway",
    "Academic Block entrance is directly opposite",
  ],
};

/* Quick campus FAQs the assistant can answer without a location match */
const FAQ = [
  { q: ["library hours", "library timing", "library open", "library close"],
    a: `📚 The Central Library is open ${CAMPUS.libraryHours}.` },
  { q: ["canteen hours", "canteen timing", "canteen open", "canteen close", "food timing"],
    a: `🍽️ The Canteen is open ${CAMPUS.canteenHours}.` },
  { q: ["wifi", "wi-fi", "internet"],
    a: "📶 Campus Wi-Fi is available in the Academic Block and Library. Ask the Admin Block for login credentials." },
  { q: ["id card", "student id", "lost id"],
    a: "🪪 For a lost or new student ID card, visit the Admin Block, Room AD-05." },
  { q: ["fee", "fees payment", "pay fees"],
    a: "💳 Fee payments are handled at the Accounts section in the Admin Block, Room AD-02." },
];
